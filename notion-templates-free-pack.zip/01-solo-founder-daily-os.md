# Solo Founder Daily OS — Notion/Obsidian Template
Version 1.0 · Free · Dhaher Autobot Ventures

## Import
Notion: create page → "Import" → paste this markdown. Obsidian: drop file into vault.

## Daily Dashboard
| Field | Value |
|---|---|
| Date | {{date}} |
| Energy (1-5) |  |
| Top Outcome (ONE thing) |  |

## Time Blocks
| Block | Focus | Done? |
|---|---|---|
| Deep 1 (90m) |  | ☐ |
| Shallow batch (45m) |  | ☐ |
| Deep 2 (90m) |  | ☐ |

## Shutdown Ritual (5 min)
1. Log wins (3 bullets)
2. Log friction (1 bullet — what blocked you)
3. Set tomorrow's Top Outcome
4. Close all loops: inbox zero? calendar checked? notes filed?

## Weekly Review (Sunday, 20 min)
- Wins that compounded:
- What to kill next week:
- One experiment for next week:

## Rules
- If the day has no Top Outcome by 10am, the day is reactive. Fix or accept.
- Energy <3 → do shallow only. No guilt.
