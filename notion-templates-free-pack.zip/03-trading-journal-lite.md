# Trading Journal Lite — QNA-Compatible Template
Version 1.0 · Free · Dhaher Autobot Ventures

## Trade Log
| # | Date | Pair | Dir | Entry | SL | TP | R:R | Result (R) | Setup | Screenshot ref |
|---|------|------|-----|-------|----|----|-----|-----------|-------|----------------|
| 1 |  |  |  |  |  |  |  |  |  |  |

## Pre-Trade Checklist (ALL must be YES)
- [ ] HTF bias clear (H2/D1)
- [ ] Liquidity target identified
- [ ] Risk ≤0.5% account
- [ ] Daily loss limit not hit (<1%)
- [ ] News window avoided or accounted
- Any NO = NO TRADE. No exceptions.

## Weekly Metrics
| Week | Trades | Win% | Avg R | Max DD | Rule violations |
|---|---|---|---|---|---|
| W1 |  |  |  |  |  |

Rule violation >0 → next week size halved. Two weeks violating → stop, review system.

## Postmortem Prompts (per losing trade)
1. Setup valid but execution bad? → execution note
2. Setup invalid (forced trade)? → tag "FOMO"/"boredom"/"revenge"
3. Market condition mismatch? → note regime
