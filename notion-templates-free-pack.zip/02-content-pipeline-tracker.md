# Content Pipeline Tracker — Kanban Template
Version 1.0 · Free · Dhaher Autobot Ventures

## Columns: IDEA → RESEARCH → DRAFT → EDIT → SCHEDULED → PUBLISHED

## Card Format
| Field | Value |
|---|---|
| Title |  |
| Hook (first line) |  |
| Platform | YT / Shorts / X / Blog |
| Status | IDEA |
| Due | {{date+7}} |
| Repurpose plan | short / thread / newsletter |

## Idea Backlog Rules
- New idea = one line + hook. No more.
- Every Sunday: delete bottom 30% (they aged out).
- Max 20 backlog items. Full backlog = stop consuming, start shipping.

## Velocity Tracker (weekly)
Week | Shipped | Planned | Ratio
|---|---|---|---|
| W1 |  | 5 |  |

Ratio <60% two weeks in a row → cut scope per piece, not quality.
